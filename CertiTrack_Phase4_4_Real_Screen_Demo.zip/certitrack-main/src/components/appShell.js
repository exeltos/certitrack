import { initTheme } from '../shared/theme.js';
import { renderSidebar } from './sidebar.js';
import { renderPageHeader } from './pageHeader.js';

const LOGO = '/assets/images/certitrack-logo.png';

function themeButton() {
  return `
    <button id="theme-toggle" aria-label="Εναλλαγή Θέματος"
      class="p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-700 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700 transition">
      <svg id="icon-moon" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
        <path d="M17.293 13.293A8 8 0 116.707 2.707a6 6 0 0010.586 10.586z"/>
      </svg>
      <svg id="icon-sun" class="w-5 h-5 hidden" fill="currentColor" viewBox="0 0 20 20">
        <path d="M10 2a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 2zM10 14.25a4.25 4.25 0 100-8.5 4.25 4.25 0 000 8.5z"/>
      </svg>
    </button>`;
}

function logo(title = 'CertiTrack', titleHtml = '') {
  return `
    <div class="flex items-center gap-2 min-w-0">
      <img src="${LOGO}" alt="CertiTrack Logo" class="ct-shell-logo h-16 w-auto">
      ${titleHtml || `<h1 class="text-xl font-bold text-blue-700 dark:text-teal-400 truncate">${title}</h1>`}
    </div>`;
}

function publicHeader({ links = [] } = {}) {
  return `
    <header class="ct-header bg-white dark:bg-gray-900 shadow-md">
      <div class="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4 p-4">
        ${logo()}
        <nav class="flex flex-wrap items-center justify-center sm:justify-end gap-3 text-sm text-gray-700 dark:text-gray-300">
          ${links.map(link => `<a href="${link.href}" class="hover:underline">${link.label}</a>`).join('')}
          ${themeButton()}
        </nav>
      </div>
    </header>`;
}

function companyHeader(kind) {
  if (kind === 'certificates') {
    return `
      <header class="ct-header sticky top-0 z-50 bg-white dark:bg-gray-900 px-4 py-3 shadow-md">
        <div class="max-w-6xl mx-auto flex justify-between items-center gap-4">
          ${logo('', `<h1 id="companyHeader" class="text-xl font-semibold text-blue-700 dark:text-teal-400">Πιστοποιητικά - <span id="companyName"></span></h1>`)}
          <div class="flex items-center gap-3">
            <span id="supplierCount" class="hidden"></span>
            <button id="notifyBtn" class="relative text-gray-600 dark:text-gray-200" title="Ειδοποιήσεις">
              <i data-lucide="bell" class="w-5 h-5"></i>
              <span id="notifyCount" class="absolute -top-1 -right-2 bg-red-500 text-white text-xs rounded-full px-1 hidden"></span>
            </button>
            <button id="exportMenuBtn" class="text-gray-700 dark:text-white hover:text-blue-600" title="Εξαγωγή"><i data-lucide="download" class="w-5 h-5"></i></button>
            ${themeButton()}
          </div>
        </div>
      </header>`;
  }
  if (kind === 'profile') {
    return `
      <header class="ct-header bg-white dark:bg-gray-900 shadow-md">
        <div class="max-w-6xl mx-auto flex justify-between items-center p-4 gap-4">
          ${logo('', `<h1 id="supplierHeader" class="text-xl font-semibold text-blue-700 dark:text-teal-400">CertiTrack <span id="userTypeLabel"></span></h1>`)}
          <div class="flex items-center gap-3">
            <a href="/pages/company/dashboard.html" class="text-sm text-gray-600 dark:text-gray-300 hover:underline">Επιστροφή</a>
            ${themeButton()}
            <button id="logoutBtn" class="text-red-500 hover:text-red-700" title="Αποσύνδεση"><i data-lucide="log-out"></i></button>
          </div>
        </div>
      </header>`;
  }
  if (kind === 'supplier') {
    return `
      <header class="ct-header bg-white dark:bg-gray-900 shadow-md">
        <div class="max-w-6xl mx-auto flex justify-between items-center p-4 gap-4">
          ${logo('', `<h1 id="pageHeader" class="text-xl font-semibold text-blue-700 dark:text-teal-400">CertiTrack</h1>`)}
          <div class="flex items-center gap-3">
            <a href="/pages/company/dashboard.html" class="text-sm text-gray-600 dark:text-gray-300 hover:underline">← Επιστροφή</a>
            <button id="downloadBtn" class="hidden" title="Εξαγωγή"><i data-lucide="download"></i></button>
            ${themeButton()}
          </div>
        </div>
      </header>`;
  }
  return `
    <header class="ct-header sticky top-0 bg-white dark:bg-gray-900 p-4 shadow-md z-50">
      <div class="max-w-6xl mx-auto flex justify-between items-center gap-4">
        ${logo('', `<h1 id="companyHeader" class="text-xl font-semibold text-blue-700 dark:text-teal-400">CertiTrack - <span id="companyName"></span></h1>`)}
        <div class="flex items-center gap-3">
          <a href="/pages/company/profile.html" title="Ρυθμίσεις" class="p-2 rounded-lg text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-white"><i data-lucide="settings"></i></a>
          ${themeButton()}
          <button id="logoutBtn" class="text-red-500 hover:text-red-700" title="Αποσύνδεση"><i data-lucide="log-out"></i></button>
        </div>
      </div>
    </header>`;
}

function supplierHeader(kind) {
  if (kind === 'profile') {
    return `
      <header class="ct-header bg-white dark:bg-gray-900 shadow-md">
        <div class="max-w-6xl mx-auto flex justify-between items-center p-4 gap-4">
          ${logo('', `<h1 id="supplierHeader" class="text-xl font-semibold text-blue-700 dark:text-teal-400">CertiTrack <span id="userTypeLabel"></span></h1>`)}
          <div class="flex items-center gap-3">
            <a href="/pages/supplier/certificates.html" class="text-sm text-gray-600 dark:text-gray-300 hover:underline">Επιστροφή</a>
            ${themeButton()}
            <button id="logoutBtn" class="text-red-500 hover:text-red-700" title="Αποσύνδεση"><i data-lucide="log-out"></i></button>
          </div>
        </div>
      </header>`;
  }
  return `
    <header class="ct-header sticky top-0 z-50 bg-white dark:bg-gray-900 px-4 py-3 shadow-md">
      <div class="max-w-6xl mx-auto flex justify-between items-center gap-4">
        ${logo('', `
          <div>
            <div class="flex items-center gap-2 text-lg font-bold text-blue-700 dark:text-teal-400">
              <span>Πιστοποιητικά</span>
              <button id="notifyBtn" class="relative" title="Ειδοποιήσεις"><i data-lucide="bell" class="w-5 h-5"></i><span id="notifyCount" class="absolute -top-1 -right-2 bg-red-500 text-white text-xs rounded-full px-1 hidden"></span></button>
            </div>
            <div id="userGreeting" class="text-sm text-gray-500 dark:text-gray-400">Καλώς ήρθες, Χρήστης</div>
          </div>`)}
        <div class="flex items-center gap-3">
          <button id="exportMenuBtn" class="text-gray-700 dark:text-white hover:text-blue-600" title="Εξαγωγή"><i data-lucide="download"></i></button>
          <button id="userSettingsBtn" class="text-gray-700 dark:text-white hover:text-blue-600" title="Ρυθμίσεις"><i data-lucide="settings"></i></button>
          ${themeButton()}
          <button id="logoutBtn" class="text-red-500 hover:text-red-700" title="Αποσύνδεση"><i data-lucide="log-out"></i></button>
        </div>
      </div>
    </header>`;
}

function adminHeader() {
  return `
    <header class="ct-header bg-white dark:bg-gray-900 shadow-md">
      <div class="max-w-6xl mx-auto flex justify-between items-center p-4 gap-4">
        ${logo('CertiTrack - Διαχειριστής')}
        <div class="flex items-center gap-3">
          <button id="exportBtn" class="text-gray-600 dark:text-gray-300" title="Εξαγωγή"><i data-lucide="download"></i></button>
          <button id="userSettingsBtn" class="text-gray-600 dark:text-gray-300" title="Ρυθμίσεις"><i data-lucide="settings"></i></button>
          ${themeButton()}
          <button id="logoutBtn" class="text-red-500 hover:text-red-700" title="Αποσύνδεση"><i data-lucide="log-out"></i></button>
        </div>
      </div>
    </header>`;
}

function resolveHeader(page) {
  const publicLinks = {
    home: [
      { href: '/pages/auth/company-register.html', label: 'Εγγραφή Εταιρείας' },
      { href: '/pages/auth/supplier-register.html', label: 'Εγγραφή Προμηθευτή' }
    ],
    login: [
      { href: '/index.html', label: 'Αρχική' },
      { href: '/pages/auth/company-register.html', label: 'Εγγραφή Εταιρείας' },
      { href: '/pages/auth/supplier-register.html', label: 'Εγγραφή Προμηθευτή' }
    ],
    register: [{ href: '/index.html', label: 'Αρχική' }],
    forgot: [{ href: '/pages/auth/login.html', label: 'Σύνδεση' }],
    reset: []
  };

  if (page === 'demo') return publicHeader({ links: [
    { href: '/index.html', label: 'Αρχική' },
    { href: '/pages/auth/login.html', label: 'Σύνδεση' }
  ] });
  if (page === 'home') return publicHeader({ links: publicLinks.home });
  if (page === 'auth-login') return publicHeader({ links: publicLinks.login });
  if (page === 'auth-company-register' || page === 'auth-supplier-register') return publicHeader({ links: publicLinks.register });
  if (page === 'auth-forgot') return publicHeader({ links: publicLinks.forgot });
  if (page === 'auth-reset') return publicHeader({ links: publicLinks.reset });
  if (page === 'company-dashboard') return companyHeader('dashboard');
  if (page === 'company-certificates') return companyHeader('certificates');
  if (page === 'company-profile') return companyHeader('profile');
  if (page === 'company-supplier') return companyHeader('supplier');
  if (page === 'supplier-certificates') return supplierHeader('certificates');
  if (page === 'supplier-profile') return supplierHeader('profile');
  if (page === 'admin-dashboard') return adminHeader();
  return publicHeader();
}


const PAGE_NAV = {
  'company-dashboard': ['company', 'suppliers'],
  'company-certificates': ['company', 'certificates'],
  'company-profile': ['company', 'profile'],
  'company-supplier': ['company', 'suppliers'],
  'supplier-certificates': ['supplier', 'certificates'],
  'supplier-profile': ['supplier', 'profile'],
  'admin-dashboard': ['admin', 'dashboard']
};

function mountAuthenticatedLayout(page) {
  const nav = PAGE_NAV[page];
  const sidebarMount = document.getElementById('app-sidebar');
  if (!nav || !sidebarMount) return;
  sidebarMount.innerHTML = renderSidebar(nav[0], nav[1]);
  const pageHeaderMount = document.getElementById('app-page-header');
  if (pageHeaderMount) pageHeaderMount.innerHTML = renderPageHeader(page);
  document.body.classList.add('ct-auth-page');
}

export function renderFooter() {
  return `<footer class="ct-footer bg-white dark:bg-gray-900 text-center py-4 border-t dark:border-gray-800">
    <p class="text-sm text-gray-500 dark:text-gray-400">© ${new Date().getFullYear()} CertiTrack</p>
  </footer>`;
}

export function initAppShell() {
  const page = document.body.dataset.page || 'home';
  const headerMount = document.getElementById('app-header');
  const footerMount = document.getElementById('app-footer');

  if (headerMount) headerMount.innerHTML = resolveHeader(page);
  if (footerMount) footerMount.innerHTML = renderFooter();
  mountAuthenticatedLayout(page);

  initTheme();
  if (window.lucide?.createIcons) window.lucide.createIcons();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAppShell, { once: true });
} else {
  initAppShell();
}
