const META = {
  'company-dashboard': {
    eyebrow: 'CertiTrack / Εταιρεία',
    title: 'Προμηθευτές',
    description: 'Διαχείριση συνεργαζόμενων προμηθευτών και πρόσβαση στα πιστοποιητικά τους.'
  },
  'company-certificates': {
    eyebrow: 'CertiTrack / Εταιρεία',
    title: 'Πιστοποιητικά εταιρείας',
    description: 'Κεντρική διαχείριση των πιστοποιητικών της εταιρείας.'
  },
  'company-profile': {
    eyebrow: 'CertiTrack / Εταιρεία',
    title: 'Ρυθμίσεις λογαριασμού',
    description: 'Στοιχεία εταιρείας και ασφάλεια λογαριασμού.'
  },
  'company-supplier': {
    eyebrow: 'CertiTrack / Προμηθευτής',
    title: 'Καρτέλα προμηθευτή',
    description: 'Στοιχεία συνεργάτη και διαθέσιμα πιστοποιητικά.'
  },
  'supplier-certificates': {
    eyebrow: 'CertiTrack / Προμηθευτής',
    title: 'Πιστοποιητικά',
    description: 'Διαχείριση, ισχύς και κοινοποίηση των πιστοποιητικών σας.'
  },
  'supplier-profile': {
    eyebrow: 'CertiTrack / Προμηθευτής',
    title: 'Ρυθμίσεις λογαριασμού',
    description: 'Στοιχεία προμηθευτή και ασφάλεια λογαριασμού.'
  },
  'admin-dashboard': {
    eyebrow: 'CertiTrack / Διαχείριση',
    title: 'Κέντρο διαχείρισης',
    description: 'Εταιρείες, προμηθευτές και κατάσταση της πλατφόρμας.'
  }
};

export function renderPageHeader(page) {
  const meta=META[page];
  if (!meta) return '';
  return `<section class="ct-page-header">
    <div>
      <div class="ct-page-header__eyebrow">${meta.eyebrow}</div>
      <h1 class="ct-page-header__title">${meta.title}</h1>
      <p class="ct-page-header__description">${meta.description}</p>
    </div>
    <div id="page-header-actions" class="ct-page-header__actions"></div>
  </section>`;
}
