import { demoData } from './demoData.js';
import { installDemoBanner, protectDemoWrites } from './demoSession.js';

function badge(status) {
  const labels = {
    active:'Ενεργό', soon:'Προς λήξη', expired:'Ληγμένο',
    compliant:'Συμμορφωμένος', attention:'Προσοχή', critical:'Ελλείψεις',
    shared:'Κοινόχρηστο', private:'Προσωπικό', granted:'Πρόσβαση', blocked:'Αποκλεισμένος'
  };
  return `<span class="demo-badge demo-badge--${status}">${labels[status] || status}</span>`;
}

function stat(label,value,note,icon) {
  return `<article class="ct-card demo-real-kpi">
    <div class="demo-real-kpi__icon"><i data-lucide="${icon}"></i></div>
    <div><strong>${value}</strong><span>${label}</span><small>${note}</small></div>
  </article>`;
}

function contentRoot() {
  return document.querySelector('.ct-content-page') || document.querySelector('main');
}

function companyDashboard() {
  installDemoBanner('company');
  const d=demoData.company;
  const root=contentRoot();
  if (!root) return;
  root.innerHTML=`
    <section class="demo-real-toolbar">
      <div class="demo-real-search"><i data-lucide="search"></i><input placeholder="Αναζήτηση προμηθευτή, ΑΦΜ..." /></div>
      <button class="ct-btn ct-btn-primary" data-demo-write><i data-lucide="plus"></i> Νέος προμηθευτής</button>
    </section>
    <section class="demo-real-kpis">
      ${stat('Προμηθευτές',d.stats.suppliers,'Συνδεδεμένοι','users')}
      ${stat('Συμμορφωμένοι',d.stats.compliant,'Χωρίς ελλείψεις','shield-check')}
      ${stat('Προς λήξη',d.stats.expiring,'Εντός 30 ημερών','clock-3')}
      ${stat('Ελλείψεις',d.stats.missing,'Απαιτούν ενέργεια','triangle-alert')}
    </section>
    <section class="ct-card demo-real-panel">
      <div class="demo-real-panel__head"><div><h2>Οι προμηθευτές μου</h2><p>Κατάσταση πιστοποιητικών και συμμόρφωσης</p></div><span>${d.suppliers.length} demo εγγραφές</span></div>
      <div class="demo-real-table">
        ${d.suppliers.map((s,i)=>`
          <a class="demo-real-supplier" href="/pages/company/supplier.html?demoSupplier=${i}">
            <div class="demo-real-company"><span>${s.name.slice(0,2).toUpperCase()}</span><div><strong>${s.name}</strong><small>ΑΦΜ ${s.afm}</small></div></div>
            <div class="demo-real-mobile-label">Πιστοποιητικά <strong>${s.certs}</strong></div>
            <div class="demo-real-score"><span><i style="width:${s.score}%"></i></span><b>${s.score}%</b></div>
            <div>${badge(s.status)}</div>
            <i data-lucide="chevron-right" class="demo-real-arrow"></i>
          </a>`).join('')}
      </div>
    </section>`;
  bindDemoWrites();
}

function companyCertificates() {
  installDemoBanner('company');
  const d=demoData.company;
  const root=contentRoot();
  if (!root) return;
  root.innerHTML=`
    <section class="demo-real-toolbar">
      <div class="demo-real-search"><i data-lucide="search"></i><input placeholder="Αναζήτηση πιστοποιητικού..." /></div>
      <button class="ct-btn ct-btn-primary" data-demo-write><i data-lucide="plus"></i> Νέο πιστοποιητικό</button>
    </section>
    <section class="demo-real-kpis demo-real-kpis--compact">
      ${stat('Σύνολο',d.certificates.length,'Πιστοποιητικά','files')}
      ${stat('Ενεργά',2,'Σε ισχύ','circle-check')}
      ${stat('Προς λήξη',2,'Εντός 30 ημερών','clock-3')}
      ${stat('Ληγμένα',0,'Δεν υπάρχουν','circle-x')}
    </section>
    <section class="demo-certificate-grid">
      ${d.certificates.map(c=>`
        <article class="ct-card demo-certificate-card">
          <div class="demo-certificate-card__top"><div class="demo-file-icon"><i data-lucide="file-check-2"></i></div>${badge(c.status)}</div>
          <h3>${c.title}</h3><p>${c.type}</p>
          <small>Λήξη ${new Date(c.expires).toLocaleDateString('el-GR')}</small>
          <div class="demo-certificate-card__actions"><button data-demo-write><i data-lucide="eye"></i> Προβολή</button><button data-demo-write><i data-lucide="pencil"></i></button></div>
        </article>`).join('')}
    </section>`;
  bindDemoWrites();
}

function supplierCertificates() {
  installDemoBanner('supplier');
  const d=demoData.supplier;
  const root=contentRoot();
  if (!root) return;
  root.innerHTML=`
    <section class="demo-real-toolbar">
      <div class="demo-real-search"><i data-lucide="search"></i><input placeholder="Αναζήτηση πιστοποιητικού..." /></div>
      <button class="ct-btn ct-btn-primary" data-demo-write><i data-lucide="plus"></i> Νέο πιστοποιητικό</button>
    </section>
    <section class="demo-real-kpis demo-real-kpis--compact">
      ${stat('Πιστοποιητικά',d.stats.certificates,'Σύνολο','files')}
      ${stat('Ενεργά',d.stats.active,'Σε ισχύ','circle-check')}
      ${stat('Προς λήξη',d.stats.expiring,'Εντός 30 ημερών','clock-3')}
      ${stat('Εταιρείες',d.stats.companies,'Σας έχουν αποθηκευμένο','building-2')}
    </section>
    <div class="demo-real-two-col">
      <section>
        <div class="demo-section-heading"><div><h2>Πιστοποιητικά</h2><p>Ισχύς και ορατότητα</p></div></div>
        <div class="demo-certificate-grid demo-certificate-grid--single">
          ${d.certificates.map(c=>`
            <article class="ct-card demo-certificate-row">
              <div class="demo-file-icon"><i data-lucide="file-check-2"></i></div>
              <div><h3>${c.title}</h3><small>${c.type} · λήξη ${new Date(c.expires).toLocaleDateString('el-GR')}</small></div>
              <div class="demo-certificate-row__badges">${badge(c.visibility)}${badge(c.status)}</div>
            </article>`).join('')}
        </div>
      </section>
      <aside id="companies" class="ct-card demo-companies-panel">
        <div class="demo-section-heading"><div><h2>Οι εταιρείες μου</h2><p>Ποιοι σας έχουν αποθηκευμένο</p></div></div>
        ${d.companies.map(c=>`<div class="demo-company-item"><div><strong>${c.name}</strong><small>ΑΦΜ ${c.afm}</small></div>${badge(c.access)}</div>`).join('')}
      </aside>
    </div>`;
  bindDemoWrites();
}

function supplierDetail() {
  installDemoBanner('company');
  const index=Number(new URLSearchParams(location.search).get('demoSupplier') || 0);
  const s=demoData.company.suppliers[index] || demoData.company.suppliers[0];
  const root=contentRoot();
  if (!root) return;
  root.innerHTML=`
    <section class="ct-card demo-detail-card">
      <div class="demo-detail-card__header">
        <div class="demo-real-company"><span>${s.name.slice(0,2).toUpperCase()}</span><div><h2>${s.name}</h2><small>ΑΦΜ ${s.afm}</small></div></div>
        ${badge(s.status)}
      </div>
      <div class="demo-detail-stats"><div><small>Compliance</small><strong>${s.score}%</strong></div><div><small>Πιστοποιητικά</small><strong>${s.certs}</strong></div><div><small>Προς λήξη</small><strong>${s.expiring}</strong></div><div><small>Ελλείψεις</small><strong>${s.missing}</strong></div></div>
    </section>
    <section class="ct-card demo-real-panel"><div class="demo-real-panel__head"><div><h2>Πιστοποιητικά προμηθευτή</h2><p>Shared demo certificates</p></div></div>
      <div class="demo-empty-preview"><i data-lucide="file-check-2"></i><strong>Demo certificate list</strong><p>Η πραγματική εφαρμογή εμφανίζει εδώ τα κοινόχρηστα πιστοποιητικά του προμηθευτή.</p></div>
    </section>`;
}

function profile(role) {
  installDemoBanner(role);
  const root=contentRoot();
  const d=role==='company' ? demoData.company : demoData.supplier;
  if (!root) return;
  root.innerHTML=`
    <section class="ct-card demo-profile-card">
      <div class="demo-section-heading"><div><h2>Στοιχεία λογαριασμού</h2><p>Demo mode · μόνο για προβολή</p></div></div>
      <label>Επωνυμία<input value="${d.name}" disabled></label>
      <label>Email<input value="demo@certitrack.gr" disabled></label>
      <label>ΑΦΜ<input value="${role==='company' ? d.afm : '099999991'}" disabled></label>
      <button class="ct-btn ct-btn-secondary" data-demo-write>Αλλαγή κωδικού</button>
    </section>`;
  bindDemoWrites();
}

function bindDemoWrites() {
  document.querySelectorAll('[data-demo-write]').forEach(el=>el.addEventListener('click',e=>{e.preventDefault(); protectDemoWrites();}));
  window.lucide?.createIcons();
}

export function renderCompanyDashboardDemo(){ companyDashboard(); }
export function renderCompanyCertificatesDemo(){ companyCertificates(); }
export function renderSupplierCertificatesDemo(){ supplierCertificates(); }
export function renderSupplierDetailDemo(){ supplierDetail(); }
export function renderProfileDemo(role){ profile(role); }
