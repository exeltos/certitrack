export const demoData = {
  company: {
    name: 'DEMO HEALTHCARE A.E.',
    afm: '999999999',
    stats: {
      suppliers: 18,
      compliant: 13,
      expiring: 3,
      missing: 2
    },
    suppliers: [
      { name: 'MedSupply A.E.', afm: '099999991', score: 100, status: 'compliant', certs: 8, expiring: 0, missing: 0 },
      { name: 'CleanCare Services', afm: '099999992', score: 83, status: 'attention', certs: 6, expiring: 1, missing: 0 },
      { name: 'BioLab Solutions', afm: '099999993', score: 67, status: 'attention', certs: 5, expiring: 1, missing: 1 },
      { name: 'TechMed Systems', afm: '099999994', score: 92, status: 'compliant', certs: 7, expiring: 1, missing: 0 },
      { name: 'SafeWaste ΕΠΕ', afm: '099999995', score: 58, status: 'critical', certs: 4, expiring: 0, missing: 2 }
    ],
    certificates: [
      { title: 'ISO 9001', type: 'ISO 9001', owner: 'DEMO HEALTHCARE A.E.', expires: '2027-05-18', status: 'active' },
      { title: 'ISO 27001', type: 'ISO 27001', owner: 'DEMO HEALTHCARE A.E.', expires: '2026-09-03', status: 'soon' },
      { title: 'Ασφαλιστική ενημερότητα', type: 'Ασφαλιστική ενημερότητα', owner: 'DEMO HEALTHCARE A.E.', expires: '2026-08-27', status: 'soon' },
      { title: 'Άδεια λειτουργίας', type: 'Άδεια λειτουργίας', owner: 'DEMO HEALTHCARE A.E.', expires: '2028-01-15', status: 'active' }
    ],
    activity: [
      { text: 'Η MedSupply A.E. ανανέωσε το ISO 13485', time: 'Πριν 18 λεπτά', kind: 'success' },
      { text: 'Το ISO 27001 της εταιρείας λήγει σύντομα', time: 'Πριν 1 ώρα', kind: 'warning' },
      { text: 'Η BioLab Solutions έχει 1 ελλιπές δικαιολογητικό', time: 'Σήμερα', kind: 'danger' },
      { text: 'Νέος προμηθευτής: SafeWaste ΕΠΕ', time: 'Χθες', kind: 'info' }
    ]
  },
  supplier: {
    name: 'MedSupply A.E.',
    stats: {
      certificates: 8,
      active: 6,
      expiring: 1,
      companies: 4
    },
    certificates: [
      { title: 'ISO 9001', type: 'ISO 9001', expires: '2027-06-30', status: 'active', visibility: 'shared' },
      { title: 'ISO 13485', type: 'ISO 13485', expires: '2027-02-12', status: 'active', visibility: 'shared' },
      { title: 'CE Medical Devices', type: 'CE', expires: '2026-09-16', status: 'soon', visibility: 'shared' },
      { title: 'Ασφάλιση αστικής ευθύνης', type: 'Ασφάλιση', expires: '2026-12-20', status: 'active', visibility: 'shared' },
      { title: 'Εσωτερική αξιολόγηση', type: 'Άλλο', expires: '2027-01-10', status: 'active', visibility: 'private' }
    ],
    companies: [
      { name: 'DEMO HEALTHCARE A.E.', afm: '999999999', access: 'granted' },
      { name: 'Κλινική Αλφα Α.Ε.', afm: '099900001', access: 'granted' },
      { name: 'Medical Center Beta', afm: '099900002', access: 'granted' },
      { name: 'Hospital Demo Group', afm: '099900003', access: 'blocked' }
    ]
  },
  admin: {
    stats: {
      companies: 34,
      suppliers: 126,
      users: 181,
      expiring: 22
    },
    organizations: [
      { name: 'DEMO HEALTHCARE A.E.', type: 'Εταιρεία', status: 'active', users: 4 },
      { name: 'MedSupply A.E.', type: 'Προμηθευτής', status: 'active', users: 2 },
      { name: 'CleanCare Services', type: 'Προμηθευτής', status: 'active', users: 1 },
      { name: 'BioLab Solutions', type: 'Προμηθευτής', status: 'pending', users: 1 },
      { name: 'Hospital Demo Group', type: 'Εταιρεία', status: 'blocked', users: 3 }
    ]
  }
};
