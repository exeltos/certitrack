import { initPage } from '/src/pages/supplier/certificates.js';
  document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) lucide.createIcons();
  initPage();
});
