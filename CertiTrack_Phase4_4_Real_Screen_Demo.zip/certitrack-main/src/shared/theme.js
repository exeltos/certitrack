const root = document.documentElement;

function syncThemeIcons() {
  const dark = root.classList.contains('dark');
  document.querySelectorAll('#icon-moon').forEach(el => el.classList.toggle('hidden', dark));
  document.querySelectorAll('#icon-sun').forEach(el => el.classList.toggle('hidden', !dark));
  document.querySelectorAll('#theme-toggle').forEach(btn => btn.setAttribute('aria-pressed', String(dark)));
}

export function applySavedTheme() {
  const saved = localStorage.getItem('theme');
  const useDark = saved === 'dark' || (!saved && window.matchMedia?.('(prefers-color-scheme: dark)').matches);
  root.classList.toggle('dark', useDark);
  syncThemeIcons();
}

export function toggleTheme() {
  const dark = !root.classList.contains('dark');
  root.classList.toggle('dark', dark);
  localStorage.setItem('theme', dark ? 'dark' : 'light');
  syncThemeIcons();
}

export function initTheme() {
  applySavedTheme();
  document.querySelectorAll('#theme-toggle').forEach(btn => {
    if (btn.dataset.ctThemeBound === '1') return;
    btn.dataset.ctThemeBound = '1';
    btn.addEventListener('click', toggleTheme);
  });
  syncThemeIcons();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTheme, { once: true });
} else {
  initTheme();
}
