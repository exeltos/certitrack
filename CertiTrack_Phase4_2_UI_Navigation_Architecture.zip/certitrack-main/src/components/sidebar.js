const NAV = {
  company: [
    { key: 'dashboard', label: 'Επισκόπηση', href: '/pages/company/dashboard.html', icon: 'layout-dashboard' },
    { key: 'suppliers', label: 'Προμηθευτές', href: '/pages/company/dashboard.html', icon: 'users' },
    { key: 'certificates', label: 'Πιστοποιητικά', href: '/pages/company/certificates.html', icon: 'badge-check' },
    { key: 'profile', label: 'Ρυθμίσεις', href: '/pages/company/profile.html', icon: 'settings' }
  ],
  supplier: [
    { key: 'certificates', label: 'Πιστοποιητικά', href: '/pages/supplier/certificates.html', icon: 'badge-check' },
    { key: 'companies', label: 'Οι εταιρείες μου', href: '/pages/supplier/certificates.html#companies', icon: 'building-2' },
    { key: 'profile', label: 'Ρυθμίσεις', href: '/pages/supplier/profile.html', icon: 'settings' }
  ],
  admin: [
    { key: 'dashboard', label: 'Επισκόπηση', href: '/pages/admin/dashboard.html', icon: 'layout-dashboard' },
    { key: 'organizations', label: 'Εταιρείες & Προμηθευτές', href: '/pages/admin/dashboard.html#organizations', icon: 'building-2' },
    { key: 'audit', label: 'System / Audit', href: '/pages/admin/dashboard.html#audit', icon: 'shield-check' }
  ]
};

export function renderSidebar(role, active = '') {
  const items = NAV[role] || [];
  if (!items.length) return '';

  return `
    <aside class="ct-sidebar" aria-label="Κύρια πλοήγηση">
      <div class="ct-sidebar__inner">
        <div class="ct-sidebar__label">${role === 'company' ? 'ΕΤΑΙΡΕΙΑ' : role === 'supplier' ? 'ΠΡΟΜΗΘΕΥΤΗΣ' : 'ΔΙΑΧΕΙΡΙΣΗ'}</div>
        <nav class="ct-sidebar__nav">
          ${items.map(item => `
            <a href="${item.href}" class="ct-nav-item ${item.key === active ? 'is-active' : ''}" ${item.key === active ? 'aria-current="page"' : ''}>
              <i data-lucide="${item.icon}" class="ct-nav-item__icon"></i>
              <span>${item.label}</span>
            </a>`).join('')}
        </nav>
      </div>
    </aside>`;
}
